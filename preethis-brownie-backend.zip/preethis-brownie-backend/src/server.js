require('dotenv').config();
const app = require('./app');
const db = require('./db');

async function start() {
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    throw new Error('JWT_SECRET must be configured with at least 32 characters');
  }
  await db.query('SELECT 1');
  const port = Number(process.env.PORT || 4000);
  app.listen(port, () => console.log(`Preethi's Brownie API listening on port ${port}`));
}
start().catch(err => { console.error('Startup failed:', err.message); process.exit(1); });
