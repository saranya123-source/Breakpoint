const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');
const offerRoutes = require('./routes/offers');
const miscRoutes = require('./routes/misc');

const app = express();
app.disable('x-powered-by');
app.use(helmet());
const allowedOrigins = (process.env.FRONTEND_ORIGIN || 'http://localhost:5500').split(',').map(s => s.trim());
app.use(cors({ origin(origin, cb) {
  if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
  return cb(new Error('Origin not allowed by CORS'));
}}));
app.use(express.json({ limit: '100kb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.get('/api/health', (_req,res) => res.json({ status:'ok', service:'Preethi’s Brownie API' }));
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/offers', offerRoutes);
app.use('/api', miscRoutes);
app.use((_req,res) => res.status(404).json({ error:'Route not found' }));
app.use((err,_req,res,_next) => {
  if (err.name === 'ZodError') return res.status(400).json({ error:'Validation failed', details:err.issues.map(i => ({ field:i.path.join('.'), message:i.message })) });
  if (err.code === 'ER_DUP_ENTRY') return res.status(409).json({ error:'A record with these details already exists' });
  if (err.code === 'ER_NO_REFERENCED_ROW_2') return res.status(400).json({ error:'Referenced record does not exist' });
  const status = err.status || (err.message === 'Origin not allowed by CORS' ? 403 : 500);
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Internal server error' : err.message });
});
module.exports = app;
