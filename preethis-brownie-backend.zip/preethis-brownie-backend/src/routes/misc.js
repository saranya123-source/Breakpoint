const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { asyncHandler } = require('../utils/http');
const { authenticate, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.get('/categories', asyncHandler(async (_req,res) => {
  const [categories] = await db.execute('SELECT category_id AS id,category_name AS name FROM categories ORDER BY category_name');
  res.json({ categories });
}));

router.post('/enquiries', asyncHandler(async (req,res) => {
  const v = z.object({ name:z.string().trim().min(2).max(100), email:z.string().email().max(100), message:z.string().trim().min(5).max(2000) }).parse(req.body);
  const [r] = await db.execute('INSERT INTO enquiries (guest_name,guest_email,message,status) VALUES (?,?,?, "Open")', [v.name,v.email,v.message]);
  res.status(201).json({ id:r.insertId, message:'Enquiry received' });
}));

router.get('/enquiries', authenticate, requireAdmin, asyncHandler(async (_req,res) => {
  const [enquiries] = await db.execute(
    `SELECT e.enquiry_id AS id,e.message,e.status,e.created_at AS createdAt,
      COALESCE(u.name,e.guest_name) AS name,COALESCE(u.email,e.guest_email) AS email
     FROM enquiries e LEFT JOIN users u ON u.user_id=e.user_id ORDER BY e.created_at DESC`);
  res.json({ enquiries });
}));

router.patch('/enquiries/:id', authenticate, requireAdmin, asyncHandler(async (req,res) => {
  const { status } = z.object({ status:z.enum(['Open','Resolved']) }).parse(req.body);
  const [r] = await db.execute('UPDATE enquiries SET status=? WHERE enquiry_id=?', [status,Number(req.params.id)]);
  if (!r.affectedRows) return res.status(404).json({ error:'Enquiry not found' });
  res.json({ message:'Enquiry updated' });
}));

router.get('/admin/summary', authenticate, requireAdmin, asyncHandler(async (_req,res) => {
  const [[orders]] = await db.execute('SELECT COUNT(*) AS totalOrders,COALESCE(SUM(total_amount),0) AS grossSales FROM orders WHERE status <> "Cancelled"');
  const [[stock]] = await db.execute('SELECT COUNT(*) AS lowStockItems FROM inventory WHERE stock_level <= low_stock_threshold');
  const [[open]] = await db.execute('SELECT COUNT(*) AS openEnquiries FROM enquiries WHERE status="Open"');
  res.json({ ...orders, ...stock, ...open });
}));
module.exports = router;
