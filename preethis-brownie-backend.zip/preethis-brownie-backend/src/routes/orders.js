const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.post('/', authenticate, asyncHandler(async (req, res) => {
  const v = z.object({
    items: z.array(z.object({ productId: z.number().int().positive(), quantity: z.number().int().min(1).max(50) })).min(1).max(30),
    deliveryAddress: z.string().trim().min(5).max(255),
    enquiry: z.string().max(500).optional()
  }).parse(req.body);
  // Combine duplicate product IDs before touching inventory.
  const quantities = new Map();
  for (const item of v.items) quantities.set(item.productId, (quantities.get(item.productId) || 0) + item.quantity);
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    let total = 0;
    const orderLines = [];
    for (const [productId, quantity] of quantities) {
      const [rows] = await conn.execute(
        `SELECT p.product_id,p.name,p.price,i.stock_level FROM products p
         JOIN inventory i ON i.product_id=p.product_id WHERE p.product_id=? AND p.is_active=1 FOR UPDATE`,
        [productId]);
      if (!rows.length) throw httpError(400, `Product ${productId} is unavailable`);
      const p = rows[0];
      if (p.stock_level < quantity) throw httpError(409, `${p.name}: only ${p.stock_level} left in stock`);
      const price = Number(p.price);
      total += price * quantity;
      orderLines.push({ productId, quantity, price });
    }
    const [order] = await conn.execute(
      `INSERT INTO orders (user_id,delivery_address,status,total_amount) VALUES (?,?, 'Placed', ?)`,
      [req.user.id, v.deliveryAddress, total]);
    for (const line of orderLines) {
      await conn.execute('INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)',
        [order.insertId,line.productId,line.quantity,line.price]);
      await conn.execute('UPDATE inventory SET stock_level=stock_level-? WHERE product_id=?',
        [line.quantity,line.productId]);
    }
    if (v.enquiry) await conn.execute('INSERT INTO enquiries (user_id,message,status) VALUES (?,?, "Open")',
      [req.user.id, `Order #${order.insertId}: ${v.enquiry}`]);
    await conn.commit();
    res.status(201).json({ orderId: order.insertId, status: 'Placed', totalAmount: Number(total.toFixed(2)), message: 'Order placed successfully' });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));

router.get('/mine', authenticate, asyncHandler(async (req, res) => {
  const [orders] = await db.execute(
    `SELECT order_id AS orderId,order_date AS orderDate,status,total_amount AS totalAmount,delivery_address AS deliveryAddress
     FROM orders WHERE user_id=? ORDER BY order_date DESC`, [req.user.id]);
  for (const o of orders) {
    const [items] = await db.execute(
      `SELECT p.name,oi.quantity,oi.price FROM order_items oi JOIN products p ON p.product_id=oi.product_id WHERE oi.order_id=?`, [o.orderId]);
    o.items = items;
  }
  res.json({ orders });
}));

router.get('/', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const [orders] = await db.execute(
    `SELECT o.order_id AS orderId,o.order_date AS orderDate,o.status,o.total_amount AS totalAmount,
      o.delivery_address AS deliveryAddress,u.name AS customerName,u.email AS customerEmail
     FROM orders o JOIN users u ON u.user_id=o.user_id ORDER BY o.order_date DESC LIMIT 200`);
  res.json({ orders });
}));

router.patch('/:id/status', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const { status } = z.object({ status: z.enum(['Placed','Preparing','Dispatched','Delivered','Cancelled']) }).parse(req.body);
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.execute('SELECT status FROM orders WHERE order_id=? FOR UPDATE', [id]);
    if (!rows.length) throw httpError(404, 'Order not found');
    const oldStatus = rows[0].status;
    if (oldStatus === 'Cancelled' || oldStatus === 'Delivered') throw httpError(409, 'This order can no longer be changed');
    if (status === 'Cancelled') {
      const [items] = await conn.execute('SELECT product_id,quantity FROM order_items WHERE order_id=?', [id]);
      for (const item of items) await conn.execute('UPDATE inventory SET stock_level=stock_level+? WHERE product_id=?', [item.quantity,item.product_id]);
    }
    await conn.execute('UPDATE orders SET status=? WHERE order_id=?', [status,id]);
    await conn.commit();
    res.json({ message: 'Order status updated', orderId: id, status });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));
module.exports = router;
