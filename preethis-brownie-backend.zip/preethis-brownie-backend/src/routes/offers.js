const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, requireAdmin } = require('../middleware/auth');
const router = express.Router();

// Active, date-valid offers power the home-page popup and the offers section.
router.get('/active', asyncHandler(async (req, res) => {
  const [offers] = await db.execute(
    `SELECT offer_id AS id,title,message,discount_type AS discountType,discount_value AS discountValue,
      coupon_code AS couponCode,minimum_order AS minimumOrder,starts_at AS startsAt,ends_at AS endsAt
     FROM offers WHERE is_active=1 AND starts_at<=NOW() AND ends_at>=NOW()
     ORDER BY priority DESC, starts_at DESC LIMIT 10`);
  res.json({ offers, popupOffer: offers[0] || null });
}));

router.get('/', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const [offers] = await db.execute('SELECT * FROM offers ORDER BY starts_at DESC');
  res.json({ offers });
}));

router.post('/', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const v = z.object({
    title: z.string().trim().min(3).max(120), message: z.string().trim().min(3).max(500),
    discountType: z.enum(['percent','fixed']), discountValue: z.number().positive(),
    couponCode: z.string().trim().max(40).optional(), minimumOrder: z.number().min(0).default(0),
    startsAt: z.string().datetime(), endsAt: z.string().datetime(), priority: z.number().int().default(0),
    isActive: z.boolean().default(true)
  }).parse(req.body);
  if (new Date(v.endsAt) <= new Date(v.startsAt)) throw httpError(400, 'endsAt must be later than startsAt');
  if (v.discountType === 'percent' && v.discountValue > 100) throw httpError(400, 'Percentage discount cannot exceed 100');
  const [r] = await db.execute(
    `INSERT INTO offers (title,message,discount_type,discount_value,coupon_code,minimum_order,starts_at,ends_at,priority,is_active)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    [v.title,v.message,v.discountType,v.discountValue,v.couponCode || null,v.minimumOrder,
     new Date(v.startsAt),new Date(v.endsAt),v.priority,Number(v.isActive)]);
  res.status(201).json({ id: r.insertId, message: 'Offer created' });
}));
module.exports = router;
