const express = require('express');
const { z } = require('zod');
const db = require('../db');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate, requireAdmin } = require('../middleware/auth');
const router = express.Router();

router.get('/', asyncHandler(async (req, res) => {
  const { q, category, featured } = req.query;
  const where = ['p.is_active = 1'];
  const params = [];
  if (q) { where.push('(p.name LIKE ? OR p.description LIKE ? OR p.tags LIKE ?)'); params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
  if (category) { where.push('c.category_name = ?'); params.push(category); }
  if (featured === 'true') where.push('p.is_featured = 1');
  const [rows] = await db.execute(
    `SELECT p.product_id AS id,p.name,p.description,p.price,p.image_url AS imageUrl,p.tags,p.is_featured AS featured,
      COALESCE(i.stock_level,0) AS stockLevel,c.category_name AS category
     FROM products p LEFT JOIN categories c ON c.category_id=p.category_id
     LEFT JOIN inventory i ON i.product_id=p.product_id
     WHERE ${where.join(' AND ')} ORDER BY p.is_featured DESC,p.name`, params);
  res.json({ products: rows });
}));

router.get('/:id/related', asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id < 1) throw httpError(400, 'Invalid product id');
  const [base] = await db.execute('SELECT category_id,tags FROM products WHERE product_id=? AND is_active=1', [id]);
  if (!base.length) throw httpError(404, 'Product not found');
  const [rows] = await db.execute(
    `SELECT p.product_id AS id,p.name,p.description,p.price,p.image_url AS imageUrl,p.tags,
      COALESCE(i.stock_level,0) AS stockLevel,c.category_name AS category
     FROM products p LEFT JOIN categories c ON c.category_id=p.category_id
     LEFT JOIN inventory i ON i.product_id=p.product_id
     WHERE p.is_active=1 AND p.product_id<>?
     ORDER BY (p.category_id = ?) DESC, p.is_featured DESC, p.name LIMIT 4`,
    [id, base[0].category_id]);
  res.json({ relatedProducts: rows });
}));

router.post('/', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const s = z.object({
    categoryId: z.number().int().positive(), name: z.string().trim().min(2).max(100),
    description: z.string().max(2000).optional(), price: z.number().positive(),
    imageUrl: z.string().url().optional(), tags: z.string().max(100).optional(),
    stockLevel: z.number().int().min(0).default(0), lowStockThreshold: z.number().int().min(0).default(10),
    featured: z.boolean().default(false)
  });
  const v = s.parse(req.body);
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [p] = await conn.execute(
      'INSERT INTO products (category_id,name,description,price,image_url,tags,is_featured) VALUES (?,?,?,?,?,?,?)',
      [v.categoryId,v.name,v.description || null,v.price,v.imageUrl || null,v.tags || null,v.featured]);
    await conn.execute('INSERT INTO inventory (product_id,stock_level,low_stock_threshold) VALUES (?,?,?)',
      [p.insertId,v.stockLevel,v.lowStockThreshold]);
    await conn.commit();
    res.status(201).json({ id: p.insertId, message: 'Product created' });
  } catch (e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));

router.patch('/:id', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const s = z.object({
    categoryId: z.number().int().positive().optional(), name: z.string().trim().min(2).max(100).optional(),
    description: z.string().max(2000).nullable().optional(), price: z.number().positive().optional(),
    imageUrl: z.string().url().nullable().optional(), tags: z.string().max(100).nullable().optional(),
    featured: z.boolean().optional(), isActive: z.boolean().optional()
  }).strict();
  const v = s.parse(req.body);
  const cols = { categoryId:'category_id',name:'name',description:'description',price:'price',imageUrl:'image_url',tags:'tags',featured:'is_featured',isActive:'is_active' };
  const entries = Object.entries(v);
  if (!entries.length) throw httpError(400, 'No fields supplied');
  const [result] = await db.execute(`UPDATE products SET ${entries.map(([k]) => `${cols[k]}=?`).join(',')} WHERE product_id=?`,
    [...entries.map(([k,val]) => typeof val === 'boolean' ? Number(val) : val), id]);
  if (!result.affectedRows) throw httpError(404, 'Product not found');
  res.json({ message: 'Product updated' });
}));

router.patch('/:id/stock', authenticate, requireAdmin, asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const v = z.object({ stockLevel: z.number().int().min(0), lowStockThreshold: z.number().int().min(0).optional() }).parse(req.body);
  const [r] = await db.execute(
    `UPDATE inventory SET stock_level=?, low_stock_threshold=COALESCE(?,low_stock_threshold) WHERE product_id=?`,
    [v.stockLevel, v.lowStockThreshold ?? null, id]);
  if (!r.affectedRows) throw httpError(404, 'Inventory record not found');
  res.json({ message: 'Stock updated' });
}));
module.exports = router;
