const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { z } = require('zod');
const db = require('../db');
const { asyncHandler, httpError } = require('../utils/http');
const { authenticate } = require('../middleware/auth');
const router = express.Router();

const registerSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(100),
  password: z.string().min(8).max(72),
  phone: z.string().trim().min(7).max(15),
  address: z.string().trim().max(255).optional().or(z.literal(''))
});

router.post('/register', asyncHandler(async (req, res) => {
  const input = registerSchema.parse(req.body);
  const email = input.email.toLowerCase();
  const [existing] = await db.execute('SELECT user_id FROM users WHERE email = ?', [email]);
  if (existing.length) throw httpError(409, 'An account with this email already exists');
  const passwordHash = await bcrypt.hash(input.password, 12);
  const [result] = await db.execute(
    `INSERT INTO users (name,email,password,phone,address,role) VALUES (?,?,?,?,?,'customer')`,
    [input.name, email, passwordHash, input.phone, input.address || null]
  );
  res.status(201).json({ message: 'Account created', user: { id: result.insertId, name: input.name, email, role: 'customer' } });
}));

router.post('/login', asyncHandler(async (req, res) => {
  const schema = z.object({ email: z.string().email(), password: z.string().min(1) });
  const input = schema.parse(req.body);
  const [rows] = await db.execute(
    'SELECT user_id, name, email, password, role FROM users WHERE email = ? LIMIT 1',
    [input.email.toLowerCase()]
  );
  if (!rows.length || !(await bcrypt.compare(input.password, rows[0].password))) {
    throw httpError(401, 'Email or password is incorrect');
  }
  const user = rows[0];
  const token = jwt.sign({ id: user.user_id, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '2h' });
  res.json({ token, expiresIn: process.env.JWT_EXPIRES_IN || '2h', user: { id: user.user_id, name: user.name, email: user.email, role: user.role } });
}));

router.get('/me', authenticate, asyncHandler(async (req, res) => {
  const [rows] = await db.execute('SELECT user_id AS id, name, email, phone, address, role FROM users WHERE user_id = ?', [req.user.id]);
  if (!rows.length) throw httpError(404, 'User not found');
  res.json({ user: rows[0] });
}));
module.exports = router;
