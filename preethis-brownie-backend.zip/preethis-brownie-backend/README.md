# Preethi's Brownie — Backend API

Node.js + Express + MySQL REST API for the **Online Brownie Ordering and Inventory Management System**. This backend follows the entities and flow in the supplied Project Review I report, with additions for related products and active offers/home-page promotion popup.

## Features
- Customer registration/login with bcrypt password hashes and JWT authentication.
- Product catalogue, categories, search, featured items, and related brownie recommendations.
- Inventory stock and low-stock thresholds.
- Transactional order placement with row locks and stock deduction to prevent overselling.
- Customer order history; admin order listing and status updates.
- Enquiries and admin dashboard summary.
- Date-valid discount offers API for a home-page popup.
- Request validation, parameterized SQL, security headers, CORS allow-list, rate limiting, centralized errors.

> Scope note: payment gateway is intentionally not included, matching the project report's current out-of-scope section. Coupon display is implemented; discount application to order totals is not enabled until you decide how coupons should be validated at checkout.

## Requirements
- Node.js 20+
- MySQL 8+
- npm

## Setup
1. Create a project folder and extract this ZIP.
2. Copy `.env.example` to `.env`, then set your database password and a unique random `JWT_SECRET` (at least 32 characters).
3. Import schema and seed data:
   ```bash
   mysql -u root -p < sql/schema.sql
   ```
4. Create a restricted database user (run in MySQL as an administrator):
   ```sql
   CREATE USER 'brownie_app'@'localhost' IDENTIFIED BY 'replace-with-a-strong-password';
   GRANT SELECT, INSERT, UPDATE, DELETE ON preethis_brownie.* TO 'brownie_app'@'localhost';
   FLUSH PRIVILEGES;
   ```
   Set matching credentials in `.env`.
5. Install and run:
   ```bash
   npm install
   npm run dev
   ```
6. Health check: `GET http://localhost:4000/api/health`

## Create the first admin safely
Generate a password hash locally (after `npm install`):
```bash
node -e "require('bcryptjs').hash('REPLACE_WITH_A_LONG_PASSWORD',12).then(console.log)"
```
Then insert the admin from a MySQL client, using the generated hash:
```sql
USE preethis_brownie;
INSERT INTO users(name,email,password,phone,role)
VALUES ('Preethi Admin','admin@yourdomain.example','PASTE_BCRYPT_HASH_HERE','0000000000','admin');
```
Delete/change placeholder values. Do not use a public admin registration endpoint.

## API overview

All routes are prefixed with `/api`. Protected routes require:
`Authorization: Bearer <token>`

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/health` | Public | Health check |
| POST | `/auth/register` | Public | Register customer |
| POST | `/auth/login` | Public | Login; returns token |
| GET | `/auth/me` | Authenticated | Current account |
| GET | `/products` | Public | Browse; optional `?q=`, `?category=`, `?featured=true` |
| GET | `/products/:id/related` | Public | Up to four related brownies |
| POST | `/products` | Admin | Create product + inventory |
| PATCH | `/products/:id` | Admin | Update product |
| PATCH | `/products/:id/stock` | Admin | Set stock/threshold |
| GET | `/categories` | Public | List categories |
| POST | `/orders` | Customer | Place order and deduct stock |
| GET | `/orders/mine` | Customer | Own order history |
| GET | `/orders` | Admin | Recent orders |
| PATCH | `/orders/:id/status` | Admin | Update status/cancel and restock |
| GET | `/offers/active` | Public | Active offers + `popupOffer` |
| GET | `/offers` | Admin | List offers |
| POST | `/offers` | Admin | Create offer |
| POST | `/enquiries` | Public | Submit contact enquiry |
| GET | `/enquiries` | Admin | List enquiries |
| PATCH | `/enquiries/:id` | Admin | Resolve/reopen enquiry |
| GET | `/admin/summary` | Admin | Sales/orders/low stock/enquiry counts |

### Example requests

Login:
```json
POST /api/auth/login
{"email":"customer@example.com","password":"your-password"}
```

Place an order:
```json
POST /api/orders
Authorization: Bearer <token>
{
  "items":[{"productId":1,"quantity":2},{"productId":3,"quantity":1}],
  "deliveryAddress":"Your delivery address in Chennai"
}
```

Create an offer (admin):
```json
POST /api/offers
Authorization: Bearer <admin-token>
{
  "title":"Weekend Brownie Treat",
  "message":"Get 10% off orders above ₹499.",
  "discountType":"percent",
  "discountValue":10,
  "couponCode":"SWEET10",
  "minimumOrder":499,
  "startsAt":"2026-10-18T00:00:00.000Z",
  "endsAt":"2026-11-18T23:59:59.000Z",
  "priority":100,
  "isActive":true
}
```

## Front-end integration: offers popup

Call `GET /api/offers/active` on the home page. If `popupOffer` is not null, show a modal with `title`, `message`, `couponCode`, `discountType`, `discountValue`, and `minimumOrder`. Dismiss it with an accessible close button and remember dismissal in `sessionStorage` so it does not reappear on every route visit. The backend returns only offers active for the current database time.

Example minimal browser code:
```js
async function loadHomeOffer() {
  const response = await fetch('http://localhost:4000/api/offers/active');
  if (!response.ok) return;
  const { popupOffer } = await response.json();
  if (!popupOffer || sessionStorage.getItem(`offer-dismissed-${popupOffer.id}`)) return;
  // Populate your modal with textContent (not innerHTML), then reveal it.
  document.querySelector('#offerTitle').textContent = popupOffer.title;
  document.querySelector('#offerMessage').textContent = popupOffer.message;
  document.querySelector('#offerCode').textContent = popupOffer.couponCode || '';
  document.querySelector('#offerModal').hidden = false;
}
```
The corresponding modal HTML/CSS should be added to the provided `browniesitePGproj.html`. Use `textContent` for API text, trap focus if implementing a full modal, support Escape/close, and provide a visible close button. This backend ZIP includes a ready-to-adapt modal example in `docs/home-offer-popup.html`.

## Related brownies integration

After loading products, for a product detail view call:
`GET /api/products/1/related`.
The endpoint ranks products from the same category first, then featured items. The current one-page HTML has six static menu cards; replace the static list with a render loop over `GET /api/products`, and optionally request related items when a product is selected. Related product results are brownies, seeded from the menu in the supplied HTML.

## Important production checklist
- Set `NODE_ENV=production`, HTTPS, strong unique secrets, and a production database account.
- Restrict `FRONTEND_ORIGIN` to your deployed site; do not use `*` with credentials.
- Use a real admin email and strong password; never commit `.env`.
- Back up the database, enable TLS between services where appropriate, and add monitoring/log rotation.
- Add automated tests and run security/dependency audits before deployment.
- Validate actual pricing, stock, delivery policies and promotional terms with the bakery owner.
- The supplied UI uses placeholder WhatsApp number `+91 99999 99999`; replace it before launch.
