#!/usr/bin/env sh
set -eu
BASE="${BASE_URL:-http://localhost:4000/api}"
printf '\nHealth check:\n'
curl -fsS "$BASE/health"
printf '\n\nProducts:\n'
curl -fsS "$BASE/products"
printf '\n\nActive offers:\n'
curl -fsS "$BASE/offers/active"
printf '\n'
