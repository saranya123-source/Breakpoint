CREATE DATABASE IF NOT EXISTS preethis_brownie
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE preethis_brownie;

CREATE TABLE IF NOT EXISTS users (
  user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  address VARCHAR(255) NULL,
  role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  category_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  product_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_id INT UNSIGNED NULL,
  name VARCHAR(100) NOT NULL,
  description TEXT NULL,
  price DECIMAL(8,2) NOT NULL,
  image_url VARCHAR(500) NULL,
  tags VARCHAR(100) NULL,
  is_featured TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL,
  CONSTRAINT chk_product_price CHECK (price >= 0),
  INDEX idx_products_active_featured (is_active,is_featured)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory (
  inventory_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id INT UNSIGNED NOT NULL UNIQUE,
  stock_level INT NOT NULL DEFAULT 0,
  low_stock_threshold INT NOT NULL DEFAULT 10,
  last_updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_inventory_product FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
  CONSTRAINT chk_stock_nonnegative CHECK (stock_level >= 0),
  CONSTRAINT chk_low_stock_nonnegative CHECK (low_stock_threshold >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  order_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  order_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Placed','Preparing','Dispatched','Delivered','Cancelled') NOT NULL DEFAULT 'Placed',
  total_amount DECIMAL(10,2) NOT NULL,
  delivery_address VARCHAR(255) NOT NULL,
  CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  INDEX idx_orders_user_date (user_id,order_date),
  INDEX idx_orders_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  order_item_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id BIGINT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(8,2) NOT NULL,
  CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(order_id) ON DELETE CASCADE,
  CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(product_id),
  CONSTRAINT chk_order_qty CHECK (quantity > 0),
  INDEX idx_order_items_order (order_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS enquiries (
  enquiry_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NULL,
  guest_name VARCHAR(100) NULL,
  guest_email VARCHAR(100) NULL,
  message TEXT NOT NULL,
  status ENUM('Open','Resolved') NOT NULL DEFAULT 'Open',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_enquiries_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
  INDEX idx_enquiries_status_date (status,created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS offers (
  offer_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(120) NOT NULL,
  message VARCHAR(500) NOT NULL,
  discount_type ENUM('percent','fixed') NOT NULL,
  discount_value DECIMAL(8,2) NOT NULL,
  coupon_code VARCHAR(40) NULL,
  minimum_order DECIMAL(10,2) NOT NULL DEFAULT 0,
  starts_at DATETIME NOT NULL,
  ends_at DATETIME NOT NULL,
  priority INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_offer_discount CHECK (discount_value > 0),
  INDEX idx_offers_active_dates (is_active,starts_at,ends_at,priority)
) ENGINE=InnoDB;

INSERT IGNORE INTO categories(category_id,category_name) VALUES
(1,'Classic'),(2,'Signature'),(3,'Eggless'),(4,'Brownie Boxes');

INSERT INTO products(category_id,name,description,price,image_url,tags,is_featured)
SELECT 1,'Classic Fudge','Dense, dark, and drenched in chocolate.',149,NULL,'Bestseller',1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Classic Fudge');
INSERT INTO products(category_id,name,description,price,image_url,tags,is_featured)
SELECT 2,'Choco Walnut Crunch','Toasted walnuts folded into fudge batter.',169,NULL,'Contains Nuts',0
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Choco Walnut Crunch');
INSERT INTO products(category_id,name,description,price,image_url,tags,is_featured)
SELECT 2,'Biscoff Swirl','Caramelized Biscoff ribboned through rich cocoa batter.',189,NULL,'Fan Favorite',1
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Biscoff Swirl');
INSERT INTO products(category_id,name,description,price,image_url,tags,is_featured)
SELECT 2,'Nutella Stuffed','A molten chocolate-hazelnut centre.',199,NULL,'New',0
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Nutella Stuffed');
INSERT INTO products(category_id,name,description,price,image_url,tags,is_featured)
SELECT 2,'Salted Caramel','Deep cocoa topped with sea-salted caramel.',179,NULL,'Bestseller',0
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Salted Caramel');
INSERT INTO products(category_id,name,description,price,image_url,tags,is_featured)
SELECT 3,'Eggless Classic','Rich, gooey brownie without egg.',159,NULL,'Eggless',0
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name='Eggless Classic');

INSERT INTO inventory(product_id,stock_level,low_stock_threshold)
SELECT p.product_id,25,5 FROM products p
LEFT JOIN inventory i ON i.product_id=p.product_id WHERE i.product_id IS NULL;

-- Sample offer for local development. Update dates/value before a real campaign.
INSERT INTO offers(title,message,discount_type,discount_value,coupon_code,minimum_order,starts_at,ends_at,priority,is_active)
SELECT 'A little brownie treat','Get 10% off orders above ₹499. Use code SWEET10.','percent',10,'SWEET10',499,
       NOW() - INTERVAL 1 DAY,NOW() + INTERVAL 30 DAY,100,1
WHERE NOT EXISTS (SELECT 1 FROM offers WHERE coupon_code='SWEET10');
